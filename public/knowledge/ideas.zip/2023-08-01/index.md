---
date: 2023-08-01
title: Python, LLMs, and new gigs
bookToc: false
aliases:
  - /2023-08-01
---
Recently started a contract gig, aimed at helping the prison system in California. It’s a slow start and unlike any other job I’ve taken on. 

There wasn’t a big, or any, welcome. At first it was depressing but now it feels right. Past jobs have been a little too heavy on “culture” and for someone who is recovering from being in shitty environments that at first seemed great, I welcome it. 

Other updates:
- Managed to get an LLM on my local machine thanks to Simon.  It came together much faster than I anticipated. Partly because I’m much better at command line work lately. 
- First round of tech review for the book will be streaming in over the next couple weeks. I’ll be curious to see what reviewers say. 
- Got a little too into having my llm write Python and other scripts for me, but it was so dang fun. All this power, and now I know how to use it!

Note to self: document how to set up go, Hugo. Get a dmg together so you can have it ready for a new machine. 