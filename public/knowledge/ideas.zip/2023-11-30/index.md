---
date: 2023-11-30
title: Wax stamps
bookToc: false
image: stamps.webp
aliases:
  - /2023-11-30
---

Used a wax stamp for the first time to address thank-you cards. It was beautiful and meditative to slowly watch this rich, luciously colored wax melt and drip, drop by drop, onto some thick and sturdy paper. Maybe I should make my own.

Other things of interest are [insight systems](/journal/insight-systems/). Anything related to tangential thinking and how it lead to deep insights fascinates me. So far, it's looking into astrology, tarot, and bone reading. I'll eventually cover things like Oblique Strategies.