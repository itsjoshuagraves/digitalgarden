---
date: 2023-09-01
title: Astrolabes, iMac G4s
bookToc: false
aliases:
  - /2023-09-01
---
 
Really interested in [this doc](https://www.pbs.org/wgbh/nova/video/star-chasers-of-senegal/) I saw on how we measure time. Astrolabes are beautiful pieces work. Why don't we make things that beautiful anymore? Everyone's obsessed with rectangles and silly minimalism, we could be obsessed over beautifully crafted things.

The Blackening earned a place in my favorite horror comedy movies. It was a delight watching the plot unfold. It was a little like Clue and Bodies Bodies Bodies, but still unique enough to stand on its own. The cast was fabulous. There's a place in my heart for movies that punch up.

Learned how to use [Lynx](https://lynx.invisible-island.net), which is a lot of fun. Surprisingly delightful to only use text.

Started to tinker with an old iMac G4 and try to turn it into something that hosts Kiwix. It's going to be a little harder going, I think. It's running an old version of OS X (Panther) that doesn't even support ExFAT or other modern Apple file formats. That makes transferring 100GB files difficult, but I’ve split files before. I think I'll:

- Upgrade to Tiger (that is the last supported OS, I think).
- Get it online and try to work faster that way. That might mean an AirPort card or just plugging it into Ethernet. 

Here's a fun idea:
- Slabtop, but has an e-ink display. The Mac I have has an HDMI port...and I have a Mac that seems to be giving up the ghost.
- I could, potentially, do this with a raspberry pi that is integrated with a keyboard.