---
bookToc: false
date: 2023-07-31
title: My intention for this new site 
aliases:
  - /2023-07-31
---
I intend to keep this wiki going for at least five years. Longer if it’s fruitful for me, but I don’t want to be chained to this forever. 

Intentions are everything to me, as success usually doesn’t come without them. 