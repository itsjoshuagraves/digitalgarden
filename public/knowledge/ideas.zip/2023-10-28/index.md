---
date: 2023-10-28
title: Retro horror
bookToc: false
draft: true
image: Goat.webp
aliases:
  - /2023-10-28
---
Solo week. My wife was out shooting the first short that she wrote and directed. I’m so excited for her, and it’s baffling how talented she, the cast and crew are. The stills I've seen look incredible. More on this when it's ready.

I spent a lot of this week looking into retro horror and mapping out a story I want to write. Then I spotted the VHS cover you see above. Coincidentally I found it on my wife’s birthday. Her name is Alison. 😊 

Misc thoughts:
- You can’t trust what you don’t test. 
- There are two forms of rejection. The first comes from taking a risk and failing. The other occurs when one takes no risks at all, guaranteeing the rejection they seek to avoid.
- Don't confuse the description of a thing with the thing itself. Maps aren't the terrain, menus aren't the meal. 