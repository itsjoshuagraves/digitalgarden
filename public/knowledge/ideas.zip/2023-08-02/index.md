---
date: 2023-08-02
title: Tech reviews for my book, horror writing
image: output.png
bookToc: false
---

Survived my first round of tech review for We Need to Talk. It was a cognitive powerlift to work through all of it. But the book is better for said feedback, which I received with joy. Just a few more, then final edits. 

I joined the horror writer association. I have intentions on more fiction writing. We’ll see about doing more once I get through book edits for WNTT. 

Feeling confident in my decision to focus on the digital garden, it’s fun to just…put stuff out there. No likes, no feedback loops. Just fun. 

Low energy week. It must have to do with the extreme levels of creativity I’ve had lately. Downloading an LLM, learning more python, toting around with dithering and image quantization via command line, writing a short story, and all the other stuff I’ve done has to have some natural balance point, does it not?

Barbie was fun. I could have done with even more pink, but I’m a sucker for that stuff. Bright, fun, and had a little bite to it. I hope Greta wins everything for it. I also saw Oppenheimer.