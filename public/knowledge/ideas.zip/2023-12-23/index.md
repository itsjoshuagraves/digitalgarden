---
date: 2023-12-12
title: New beginnings
draft: true
bookToc: false
image: thought.webp
---

2023 was a year of firsts, most of them apocalyptic. This year I:

- Got laid off
- Cut off contact with my parents
- Ended a 17 year marriage, which included daily life with my two dear animals
- Realized I was pansexual
- Realized I had ADHD
- Realized I had CPTSD
- Began EMDR therapy to address the traumas that caused my CPTSD

Everything in my life is in ruins, my spirit is shattered. So I'm going to start over. In a way, it's freeing. I don't have to care about the old me. I can look at my life and see what I was missing. What I wanted to do but couldn't because I had someone else's feelings and needs to consider.

It's okay if things don't fit right on the first try, I'm working on a foundational level so it's easy to clear the deck and start again. I will put myself back together and adorn the cracks with gold.

So, what's the new me?

- Done with people pleasing
- Sex positive
- Building a life with myself at the core
- Enjoying my own company
- Building new kinds of relationships

I am in the desert. I am healing. 