---
date: 2023-07-26
title: Skulls and Spooky Stuff
weight: 10
tags: skulls
type: docs
draft: true
summary: "I have always liked spooky stuff, and it's an inspiration for a lot of my art."
---

Even as a kid I would watch tales from the crypt with my aunt (who narced on me for watching beavis and butthead, strangely enough). I’d read Goosebumps, Bruce Coville, and anything on classic monsters I could find at the library. My first big horror book was Mary Shelley’s Frankenstein and I read that in sixth grade.

But a constant fascination for me were skeletons and skulls. They weren’t scary to me like they were to others. I wasn’t about to start collecting bones or anything, but they always remind me that things here on Earth are fleeting. What we are now, they once were. 

And that these things are with us, supporting us through every moment of our entire lives. And we usually don’t see them. 

They’re spooky, they’re fun, and they’re fascinating. 

{{< columns >}}
![](/Spooky.webp)
<--->
![](/Compliments.webp)
{{< /columns >}}