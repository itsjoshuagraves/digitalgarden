---
title: Journal
type: docs
bookToc: false
summary: Collected thoughts.
---